//
//  CollectionViewCell.swift
//  GoogleBooksApp
//
//  Created by jerry on 10/26/19.
//  Copyright © 2019 lpmetor. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
   

    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    static let identifier = "CollectionViewCell"

}
