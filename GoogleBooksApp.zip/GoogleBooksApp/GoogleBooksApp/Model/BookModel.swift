//
//  BookModel.swift
//  GoogleBooksApp
//
//  Created by jerry on 10/26/19.
//  Copyright © 2019 lpmetor. All rights reserved.
//

import Foundation
